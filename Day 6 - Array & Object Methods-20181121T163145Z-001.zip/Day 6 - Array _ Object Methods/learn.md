# Array and Object Methods

## Extra Videos And Articles
  * [Array and Object Methods](https://codeburst.io/useful-javascript-array-and-object-methods-6c7971d93230)
  * [Common Array Methods](https://www.youtube.com/watch?v=MeZVVxLn26E)
  * [Array Iteration](https://www.youtube.com/watch?v=Urwzk6ILvPQ)



